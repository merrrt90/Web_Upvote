﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","id",{title:"Pengambil  Warna UI",preview:"Pratinjau",config:"Tempel string ini ke arsip config.js anda.",predefined:"Set warna belum terdefinisi."});