var tipuedrop = {
    "pages": [
        {
            "title": "Jenna Davis",
            "thumb": "assets/images/avatars/jenna.png",
            "text": "<small>Influencer, PARIS</small>",
            "url": "/profile"
        },
        {
            "title": "Dan Walker",
            "thumb": "assets/images/avatars/dan.jpg",
            "text": "<small>Developer, NY</small>",
            "url": "/profile"
        },
        {
            "title": "Stella Bergmann",
            "thumb": "assets/images/avatars/stella.jpg",
            "text": "<small>Student, BERLIN</small>",
            "url": "/profile"
        },
        {
            "title": "Daniel Wellington",
            "thumb": "assets/images/avatars/daniel.jpg",
            "text": "<small>Teacher, LONDON</small>",
            "url": "/profile"
        },
        {
            "title": "David Kim",
            "thumb": "assets/images/avatars/david.jpg",
            "text": "<small>Developer, LA</small>",
            "url": "/profile"
        },
        {
            "title": "Edward Mayers",
            "thumb": "assets/images/avatars/edward.jpeg",
            "text": "<small>Doctor, DUBLIN</small>",
            "url": "/profile"
        },
        {
            "title": "Elise Walker",
            "thumb": "assets/images/avatars/elise.jpg",
            "text": "<small>Influencer, LONDON</small>",
            "url": "/profile"
        },
        {
            "title": "Milly Augustine",
            "thumb": "assets/images/avatars/milly.jpg",
            "text": "<small>Lawyer, ROME</small>",
            "url": "/profile"
        },
        {
            "title": "Bobby Brown",
            "thumb": "assets/images/avatars/bobby.jpg",
            "text": "<small>Designer, PARIS</small>",
            "url": "/profile"
        },
        {
            "title": "Nelly Schwartz",
            "thumb": "assets/images/avatars/nelly.png",
            "text": "<small>CFO, MELBOURNE</small>",
            "url": "/profile"
        },
        {
            "title": "Lana Henrikssen",
            "thumb": "assets/images/avatars/lana.jpeg",
            "text": "<small>Student, HELSINKI</small>",
            "url": "/profile"
        },
        {
            "title": "Gaelle Morris",
            "thumb": "assets/images/avatars/gaelle.jpeg",
            "text": "<small>Merchant, Lyon</small>",
            "url": "/profile"
        },
        {
            "title": "Mike Lasalle",
            "thumb": "assets/images/avatars/mike.jpg",
            "text": "<small>Businessman, TORONTO</small>",
            "url": "/profile"
        },
        {
            "title": "Rolf Krupp",
            "thumb": "assets/images/avatars/rolf.jpg",
            "text": "<small>Accountant, BERLIN</small>",
            "url": "/profile"
        },
        {
            "title": "Android Studio",
            "thumb": "assets/images/icons/logos/android.svg",
            "text": "<small>Technology</small>",
            "url": "/profile"
        },
        {
            "title": "Angular",
            "thumb": "assets/images/icons/logos/angular.svg",
            "text": "<small>Technology</small>",
            "url": "/profile"
        },
        {
            "title": "Domino's Pizza",
            "thumb": "assets/images/icons/logos/domino.jpg",
            "text": "<small>Pizza & Fast Food</small>",
            "url": "/profile"
        },
        {
            "title": "IMDB",
            "thumb": "assets/images/icons/logos/imdb.png",
            "text": "<small>Movies / Entertainment</small>",
            "url": "/profile"
        },
        {
            "title": "Vuejs",
            "thumb": "assets/images/icons/logos/vuejs.svg",
            "text": "<small>Technology</small>",
            "url": "/profile"
        },
        {
            "title": "Reactjs",
            "thumb": "assets/images/icons/logos/reactjs.svg",
            "text": "<small>Technology</small>",
            "url": "/profile"
        },
        {
            "title": "Photoshop",
            "thumb": "assets/images/icons/logos/photoshop.svg",
            "text": "<small>Design</small>",
            "url": "/profile"
        },
        {
            "title": "WordPress",
            "thumb": "assets/images/icons/logos/wordpress.svg",
            "text": "<small>Technology</small>",
            "url": "/profile"
        }
    ]
};
